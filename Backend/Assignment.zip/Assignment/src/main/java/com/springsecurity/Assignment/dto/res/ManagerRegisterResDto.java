package com.springsecurity.Assignment.dto.res;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter@Setter@NoArgsConstructor
public class ManagerRegisterResDto {

    private String message;
    private Boolean flag;
}
